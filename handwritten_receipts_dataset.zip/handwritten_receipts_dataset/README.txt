Handwritten Receipt Recognition (HRR) - 10 image starter dataset

images/: 10 handwritten receipt/form images
annotations/: JSON templates for HRR/KIE ground truth
ocr_lines should later contain line-level transcription and optional bounding boxes.
